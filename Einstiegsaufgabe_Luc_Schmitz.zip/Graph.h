//
// Created by lucmi on 24/02/2025.
//

#ifndef GRAPH_H
#define GRAPH_H
#include <string>
#include <vector>


class Graph {
public:
    Graph(int numNodes, std::vector<std::vector<int>> distmatrix);
    Graph(std::vector<std::array<double, 2>> coords, std::string norm);
    explicit Graph(int numNodes);

    void random2d(std::string norm, int max);

    std::vector<std::vector<int>> getDistmatrix();
    int getNumNodes() const;
    void setName(std::string name);
    std::string getName() const;

private:
    int numNodes;
    std::vector<std::vector<int>> distmatrix;
    std::string name = "unnamed";

    void calcDistmatrix(std::vector<std::array<double, 2>> coords, std::string norm);
};



#endif //GRAPH_H
